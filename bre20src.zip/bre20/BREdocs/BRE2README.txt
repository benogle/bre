*******************************************************************************
**By using Any of the code in the zip file containing this file or any other **
**code written to interact with honda ECUs, you assume all responsibility for**
**anything that happens to or with your car.                                 **
*******************************************************************************

NOTE: All furure BRE releases and ECU code will be in the zip file at	
      www.ef-honda.com/ben/tmp/obd0tezting.zip. No longer will I be 
      posting files onto pgmfi or anywhere else. If you have any questions
      use my new ECU forum at benogle.homelinux.com or the BRE forum at 
      pgmfi.org.

Last update: 06.11.05



                          **GENERAL BRE README/FAQ**

Contents:

- What do the map headers mean?
- What do the values in the maps mean?
- What do the line graphs represent?
- How do I copy a map to a different file?
- 

	Someday soon I will fill this in...
	
	Submit questions you think should be answered in here
	to ogle6@hotmail.com