#include "stdafx.h"
#include "AfrEstimation.h"