#pragma once

using namespace System;

namespace bre20
{

	public __gc class AfrEstimation: public MarshalByRefObject
	{
	protected:
		float afr;
		int fromdirection;
		int steps;

	public:
		
		AfrEstimation(float eafr, int step, int fromdir)
		{
			afr = eafr;
			fromdirection = fromdir;
			steps = step;
		};

		float getAfr()
		{
			return afr;
		}

		int getDirection()
		{
			return fromdirection;
		}

		int getSteps()
		{
			return steps;
		}
	};
}