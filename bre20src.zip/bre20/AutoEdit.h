#pragma once

using namespace System;
using namespace System::Windows::Forms;

#include "hondaecu.h"
#include "loggerData.h"

namespace bre20
{
	/// <summary> 
	/// Class for all machine editing on some ecu file. 
	///
	/// This includes AutoTune, realtime autotune, 
	/// and editing through the Logger.
	/// </summary>
	public __gc class AutoEdit
	{
	protected:

		RomRep::HondaEcu* rom;
		Form* romWind;
		LoggerKey* rtatkey;

		/*! This is an array that tells 
		the editor what cell is being
		used the most by the engine.

		index [x,0,0] is the current cell, index [x,1,0]
		is the east cell, [0,1] is the south cell, etc.
		The weights should always add up to 1.
		*/
		float weights __gc[,];
		PointF interp;
		float smchange, lgchange;
		bool percentchange, curvtec;

		///current column/row
		int curcol,curfrow, curirow;
		///map index
		int index;

		//realtime auto tune.
		bool autotune;
		float afrmap __gc[,,];
		float afr;
	//	int rowinterp,colinterp;

		float atmin, atmax, atmincell, atminfreq, atmaxrowdev, atmaxcoldev;
		int intervalcount, numintervals;

		int goodsamples __gc[,,];

		float atavg __gc[,,];
		float atfreq __gc[,,];

		///The array that tells us which cells should 
		///be auto tuned/machine edited.
		///
		///false is default. True if the cell is not to be 
		///edited.
		bool blockout __gc[,,];

		//end realtime editing.

		void afr_AfrChanged(Object* sender, RomRep::AfrChangeArgs* e);

	public:
		AutoEdit(Form* romw);

		///change the fuel at some index
		void changeFuel(float change);
		bool setFuelCell(int col, int row, float perc, float afrmeasure, float afrtarget);

		//Set the interpolation. p.X is the percentage in the current row.
		//p.Y is the percentage in the current column. i.e. p.X = 0 and 
		//p.Y = 1 means the ecu is using the next column and the current row
		//void setInterpolation(PointF p){if(p != PointF::Empty) interp = p;};
		
		///set a weight
		void setCellWeight(int col, int row, float value);
		///get a weight
		float getCellWeight(int col, int row){return weights[col,row];}
		///set a blocked out cell
		void setBlockOut(int index, int col, int row, bool value);
		///get a blocked out cell
		bool getBlockOut(int index, int col, int row){return blockout[index,col,row];}
		float getSmallChange(){return smchange;}
		float getLargeChange(){return lgchange;}

		///initialize the real time auto tuning
		void RtAutoTuneInit();
		///called when BRE is auto tuning
		void RtAutoTuneRun();
		///stops the auto tuning.
		void RtAutoTuneStop();

		bre20::LoggerKey* getLoggerKey();

		void DlEditInit();

	//--Stuff some rule must set in order for this all to work.--//

		///sets the fuel map index that being used by the ecu 
		void setIndex(int i){
			if(i<rom->getNumMaps())
				index = i;
		}
		///sets the current afr
		void setAfr(float a){afr = a;};
		///sets the current column
		void setCurrentColumn(int x){
			if(x>=0 && x<rom->getWidth())
			curcol = x;
		}
		///sets the current fuel row
		void setCurrentFuelRow(int fy){
			if(fy>=0 && fy<rom->getHeight())
			curfrow = fy;
		}

		///sets the current row
		void setCurrentIgnitionRow(int iy){
			if(iy>=0 && iy<rom->getHeight())
			curirow = iy;
		}

		int getFuelRow(){return curfrow;}
		int getIgnitionRow(){return curirow;}
		int getColumn(){return curcol;}
		float getAfr(){return afr;}
		int getIndex(){return index;}

		static float parseWeights(String* weights) __gc[,];
	};
}