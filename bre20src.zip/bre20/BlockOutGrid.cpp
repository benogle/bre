#include "stdafx.h"
#include "BlockOutGrid.h"

void bre20::BlockOutGrid::setSelection(bool blocked)
{
	int selcell __gc[] = getSelectedCells(); 
	for(int col = selcell[0]; col<=selcell[2]; col++)
	{
		for(int row = selcell[1] ; row<=selcell[3]; row++)
		{
			if(blocked)
				grid->setCellColor(col,row,System::Drawing::Color::Black);
			else
				grid->setCellColor(col,row,System::Drawing::Color::White);
		}
	}

	grid->Refresh();
}

void bre20::BlockOutGrid::setBlockout(AutoEdit* ae)
{
	for(int col = 0; col<this->grid->GridSize.Width; col++)
	{
		for(int row = 0; row<this->grid->GridSize.Height; row++)
		{
			int ind = getIndex();
			if(grid->getCellColor(col,row) == System::Drawing::Color::Black)
				ae->setBlockOut(getIndex(),col,row,true);
			else
				ae->setBlockOut(getIndex(),col,row,false);
		}
	}
}

void bre20::BlockOutGrid::setupGrid(AutoEdit* ae)
{
	for(int col = 0; col<this->grid->GridSize.Width; col++)
	{
		for(int row = 0; row<this->grid->GridSize.Height; row++)
		{
			int ind = getIndex();
			if(ae->getBlockOut(ind,col,row))
				grid->setCellColor(col,row,System::Drawing::Color::Black);
			else
				grid->setCellColor(col,row,System::Drawing::Color::White);
		}
		grid->setHeader(col,col.ToString());
	}
	for(int row = 0; row<this->grid->GridSize.Height; row++)
		grid->setRowHeader(row,row.ToString());
}

void bre20::BlockOutGrid::block_Click(System::Object *  sender, System::EventArgs *  e)
{
	setSelection(true);
}
void bre20::BlockOutGrid::unblock_Click(System::Object *  sender, System::EventArgs *  e)
{
	setSelection(false);
}

void bre20::BlockOutGrid::setupMenuItems()
{
	this->block = new System::Windows::Forms::MenuItem();
	this->unblock = new System::Windows::Forms::MenuItem();
	this->sep = new System::Windows::Forms::MenuItem();
	this->help = new System::Windows::Forms::MenuItem();
	this->contextMenu = new System::Windows::Forms::ContextMenu();

	System::Windows::Forms::MenuItem* __mcTemp__1[] = new System::Windows::Forms::MenuItem*[4];
	__mcTemp__1[0] = this->block;
	__mcTemp__1[1] = this->unblock;
	__mcTemp__1[2] = this->sep;
	__mcTemp__1[3] = this->help;
	this->contextMenu->MenuItems->AddRange(__mcTemp__1);
	this->ContextMenu = contextMenu;

	// 
	// block
	// 
	this->block->Index = 0;
	this->block->Text = S"Block Range";
	this->block->Shortcut = System::Windows::Forms::Shortcut::CtrlB;
	this->block->Click += new System::EventHandler(this, block_Click);
	// 
	// unblock
	// 
	this->unblock->Index = 1;
	this->unblock->Text = S"Unblock Range";
	this->unblock->Shortcut = System::Windows::Forms::Shortcut::CtrlU;
	this->unblock->Click += new System::EventHandler(this, unblock_Click);
	// 
	// sep
	// 
	this->sep->Index = 2;
	this->sep->Text = S"-";
	// 
	// block
	// 
	this->help->Index = 3;
	this->help->Text = S"Help";
	this->help->Click += new System::EventHandler(this, help_Click);
}