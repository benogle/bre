#pragma once

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;

#include "LabeledText.h"


namespace bre20
{
	/// <summary> 
	/// Summary for BoostEff
	///
	/// WARNING: If you change the name of this class, you will need to change the 
	///          'Resource File Name' property for the managed resource compiler tool 
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public __gc class BoostEff : public System::Windows::Forms::Form
	{
	public: 
		float getPercentage()
		{
			return perc;
		}
		BoostEff(void)
		{
			InitializeComponent();

			// 
			// textBox1
			// 
			lt = new LabeledText(S"Boost Efficiency:",S"Put in a decimal percentage",208,LabeledText::LTMODEDOUBLE);
			this->lt->Location = System::Drawing::Point(24, 32);
			this->lt->Name = S"lt";
			this->lt->TabIndex = 0;
			lt->setText(S"100");

			this->Controls->Add(lt);
		}
        
	protected: 
		float perc;
		void Dispose(Boolean disposing)
		{
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}
	private: System::Windows::Forms::Button *  ok;
	private: System::Windows::Forms::Button *  cancel;
		LabeledText* lt;
	private: System::Windows::Forms::Label *  label1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container* components;

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->ok = new System::Windows::Forms::Button();
			this->cancel = new System::Windows::Forms::Button();
			this->label1 = new System::Windows::Forms::Label();
			this->SuspendLayout();
			// 
			// ok
			// 
			this->ok->DialogResult = System::Windows::Forms::DialogResult::OK;
			this->ok->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->ok->Location = System::Drawing::Point(200, 96);
			this->ok->Name = S"ok";
			this->ok->Size = System::Drawing::Size(80, 24);
			this->ok->TabIndex = 1;
			this->ok->Text = S"OK";
			this->ok->Click += new System::EventHandler(this, ok_Click);
			// 
			// cancel
			// 
			this->cancel->DialogResult = System::Windows::Forms::DialogResult::Cancel;
			this->cancel->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->cancel->Location = System::Drawing::Point(120, 96);
			this->cancel->Name = S"cancel";
			this->cancel->Size = System::Drawing::Size(72, 24);
			this->cancel->TabIndex = 2;
			this->cancel->Text = S"Cancel";
			this->cancel->Click += new System::EventHandler(this, cancel_Click);
			// 
			// label1
			// 
			this->label1->Font = new System::Drawing::Font(S"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, (System::Byte)0);
			this->label1->Location = System::Drawing::Point(232, 48);
			this->label1->Name = S"label1";
			this->label1->Size = System::Drawing::Size(24, 16);
			this->label1->TabIndex = 3;
			this->label1->Text = S"%";
			// 
			// BoostEff
			// 
			this->AcceptButton = this->ok;
			this->AutoScaleBaseSize = System::Drawing::Size(5, 13);
			this->ClientSize = System::Drawing::Size(288, 126);
			this->ControlBox = false;
			this->Controls->Add(this->label1);
			this->Controls->Add(this->cancel);
			this->Controls->Add(this->ok);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedDialog;
			this->Name = S"BoostEff";
			this->ShowInTaskbar = false;
			this->Text = S"Boost Efficiency";
			this->ResumeLayout(false);

		}		
	private: System::Void ok_Click(System::Object *  sender, System::EventArgs *  e)
			 {
				 perc = lt->getDblValue();
				 this->Close();
			 }

	private: System::Void cancel_Click(System::Object *  sender, System::EventArgs *  e)
			 {
				 this->Close();
			 }

	};
}