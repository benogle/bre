#include "StdAfx.h"
#include "AutotuneOptions.h"
#include "child.h"

void bre20::AutotuneOptions::setupTabs(AutoEdit* ae, Form* rom)
{
	child* chld;
	try
	{
	chld = static_cast<child*>(rom);
	}
	catch(...){return;}

	grids = new BlockOutGrid*[chld->getRom()->getNumMaps()];
	for(int i =0; i<grids->Length; i++){
		grids[i] = new BlockOutGrid(i,chld->getRom()->getWidth(),chld->getRom()->getHeight(),
			String::Concat(chld->getTabConrol()->TabPages->get_Item(i*2)->Text,S" Blockout"),ae);
		this->tabControl1->TabPages->Add(grids[i]);
	}
}