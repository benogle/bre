#pragma once
#include "GridPage.h"
#include "AutoEdit.h"

using namespace System;
using namespace System::Windows::Forms;

namespace bre20
{
	/// <summary> 
	/// tab page with a grid
	/// </summary>
	public __gc class BlockOutGrid : public bre20::GridPage
	{
	public:

		BlockOutGrid(int ind, int x, int y, String * str, AutoEdit* ae):GridPage(str, x, y, 2)
		{
		//	this->ContextMenu = NULL;
			setIndex(ind);

			setupGrid(ae);
			setupMenuItems();
		}

		virtual void setBlockout(AutoEdit* ae);

	private:
		System::Windows::Forms::ContextMenu* contextMenu;
		MenuItem* block;
		MenuItem* unblock;
		MenuItem* sep;
		MenuItem* help;

		virtual void setSelection(bool blocked);
		virtual void setupGrid(AutoEdit* ae);
		virtual void setupMenuItems();

		void block_Click(System::Object *  sender, System::EventArgs *  e);
		void unblock_Click(System::Object *  sender, System::EventArgs *  e);
		void help_Click(System::Object *  sender, System::EventArgs *  e){
			MessageBox::Show("Select a range and right click to block or unblock the cells. Black cells mean BRE will not auto tune those cells.");
		}
	};
}