#pragma once

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;

#include "labeledtext.h"

namespace bre20
{
	/// <summary> 
	/// Summary for AdjustFuel
	///
	/// WARNING: If you change the name of this class, you will need to change the 
	///          'Resource File Name' property for the managed resource compiler tool 
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public __gc class AdjustFuel : public System::Windows::Forms::Form
	{
	public: 

		float getFactor()
		{
			return factor;
		}

		void setInjectors(int inj)
		{
			oldinj->setText(inj.ToString());
			newinj->setText(inj.ToString());
		}

		void setEngine(int eng)
		{
			oldsize->setText(eng.ToString());
			newsize->setText(eng.ToString());
		}

		AdjustFuel(void)
		{
			InitializeComponent();

							oldinj = new LabeledText("Old Size",S"This is the old injector size in CC",90,LabeledText::LTMODEINT);
				newinj = new LabeledText("New Size",S"This is the new injector size in CC",90,LabeledText::LTMODEINT);
				oldsize = new LabeledText("Old Size",S"This is the old engine size in CC",90,LabeledText::LTMODEINT);
				newsize = new LabeledText("New Size",S"This is the new engine size in CC",90,LabeledText::LTMODEINT);

				this->oldinj->Location = System::Drawing::Point(24, 20);
				this->oldinj->Name = S"oldinj";
				this->oldinj->TabIndex = 0;

				this->newinj->Location = System::Drawing::Point(24, 80);
				this->newinj->Name = S"newinj";
				this->newinj->TabIndex = 1;
			
				this->groupBox1->Controls->Add(this->oldinj);
				this->groupBox1->Controls->Add(this->newinj);

				this->newsize->Location = System::Drawing::Point(24, 80);
				this->newsize->Name = S"newsize";
				this->newsize->TabIndex = 2;

				this->oldsize->Location = System::Drawing::Point(24, 20);
				this->oldsize->Name = S"oldsize";
				this->oldsize->TabIndex = 3;

				this->groupBox2->Controls->Add(this->oldsize);
				this->groupBox2->Controls->Add(this->newsize);
		
		}
	private: System::Windows::Forms::Button *  cancel;

	protected: 
		float factor;
		void Dispose(Boolean disposing)
		{
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}
	private: System::Windows::Forms::GroupBox *  groupBox1;
	private: System::Windows::Forms::GroupBox *  groupBox2;

	private: LabeledText *  oldinj;
	private: LabeledText *  newinj;

	private: LabeledText *  oldsize;
	private: LabeledText *  newsize;
	private: System::Windows::Forms::Button *  okButton;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container* components;

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->groupBox1 = new System::Windows::Forms::GroupBox();
			this->groupBox2 = new System::Windows::Forms::GroupBox();
			this->okButton = new System::Windows::Forms::Button();
			this->cancel = new System::Windows::Forms::Button();
			this->SuspendLayout();
			// 
			// groupBox1
			// 
			this->groupBox1->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->groupBox1->Location = System::Drawing::Point(16, 16);
			this->groupBox1->Name = S"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(152, 152);
			this->groupBox1->TabIndex = 99;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = S"Injector Size";
			// 
			// groupBox2
			// 
			this->groupBox2->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->groupBox2->Location = System::Drawing::Point(184, 16);
			this->groupBox2->Name = S"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(152, 152);
			this->groupBox2->TabIndex = 99;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = S"Engine Size";
			// 
			// okButton
			// 
			this->okButton->DialogResult = System::Windows::Forms::DialogResult::OK;
			this->okButton->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->okButton->Location = System::Drawing::Point(248, 192);
			this->okButton->Name = S"okButton";
			this->okButton->Size = System::Drawing::Size(88, 32);
			this->okButton->TabIndex = 100;
			this->okButton->Text = S"OK";
			this->okButton->Click += new System::EventHandler(this, okButton_Click);
			// 
			// cancel
			// 
			this->cancel->DialogResult = System::Windows::Forms::DialogResult::Cancel;
			this->cancel->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->cancel->Location = System::Drawing::Point(144, 192);
			this->cancel->Name = S"cancel";
			this->cancel->Size = System::Drawing::Size(96, 32);
			this->cancel->TabIndex = 101;
			this->cancel->Text = S"Cancel";
			this->cancel->Click += new System::EventHandler(this, cancel_Click);
			// 
			// AdjustFuel
			// 
			this->AcceptButton = this->okButton;
			this->AutoScaleBaseSize = System::Drawing::Size(5, 13);
			this->CancelButton = this->cancel;
			this->ClientSize = System::Drawing::Size(352, 238);
			this->ControlBox = false;
			this->Controls->Add(this->cancel);
			this->Controls->Add(this->okButton);
			this->Controls->Add(this->groupBox1);
			this->Controls->Add(this->groupBox2);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedDialog;
			this->Name = S"AdjustFuel";
			this->ShowInTaskbar = false;
			this->Text = S"Adjust Fuel";
			this->Load += new System::EventHandler(this, AdjustFuel_Load);
			this->ResumeLayout(false);

		}		
	private: System::Void okButton_Click(System::Object *  sender, System::EventArgs *  e)
			 {
				 factor = (oldinj->getDblValue()/newinj->getDblValue()) * (newsize->getDblValue()/oldsize->getDblValue());
				this->Close();
			 }

	private: System::Void AdjustFuel_Load(System::Object *  sender, System::EventArgs *  e)
			 {


			 }

	private: System::Void cancel_Click(System::Object *  sender, System::EventArgs *  e)
			 {
				 this->Close();
			 }

};
}