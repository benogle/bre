#pragma once

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;


namespace bre20
{
	/// <summary> 
	/// Summary for ArithDialog
	///
	/// WARNING: If you change the name of this class, you will need to change the 
	///          'Resource File Name' property for the managed resource compiler tool 
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public __gc class ArithDialog : public System::Windows::Forms::Form
	{
	public: 
		ArithDialog(String * title)
		{
			InitializeComponent();
			this->Text = title;
		}

//		void setTitle(String* title)
//		{
//			this->Text = title;
//		}

		//use this to set the default number
		//i.e. 0 for addition and 1 for multiplication
		void setNumber(float num)
		{
			defaultv = num;
			this->numbox->Text = num.ToString();
		}

		float getNumber()
		{
			return value;

		}

	private: System::Windows::Forms::TextBox *  numbox;
	private: System::Windows::Forms::Button *  okbutton;
	private: System::Windows::Forms::Label *  label1;

	protected: 
		bool multiply;
		float value;
		float defaultv;

		void Dispose(Boolean disposing)
		{
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}
        
	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container* components;

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->numbox = new System::Windows::Forms::TextBox();
			this->okbutton = new System::Windows::Forms::Button();
			this->label1 = new System::Windows::Forms::Label();
			this->SuspendLayout();
			// 
			// numbox
			// 
			this->numbox->Location = System::Drawing::Point(16, 32);
			this->numbox->Name = S"numbox";
			this->numbox->Size = System::Drawing::Size(200, 20);
			this->numbox->TabIndex = 0;
			this->numbox->Text = S"";
			// 
			// okbutton
			// 
			this->okbutton->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->okbutton->Location = System::Drawing::Point(120, 72);
			this->okbutton->Name = S"okbutton";
			this->okbutton->Size = System::Drawing::Size(96, 24);
			this->okbutton->TabIndex = 1;
			this->okbutton->Text = S"OK";
			this->okbutton->Click += new System::EventHandler(this, okbutton_Click);
			// 
			// label1
			// 
			this->label1->Location = System::Drawing::Point(16, 16);
			this->label1->Name = S"label1";
			this->label1->Size = System::Drawing::Size(144, 16);
			this->label1->TabIndex = 2;
			this->label1->Text = S"Enter Number:";
			// 
			// ArithDialog
			// 
			this->AcceptButton = this->okbutton;
			this->AutoScaleBaseSize = System::Drawing::Size(5, 13);
			this->ClientSize = System::Drawing::Size(234, 110);
			this->ControlBox = false;
			this->Controls->Add(this->label1);
			this->Controls->Add(this->okbutton);
			this->Controls->Add(this->numbox);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedDialog;
			this->Name = S"ArithDialog";
			this->Text = S"ArithDialog";
			this->ResumeLayout(false);

		}		

		//

	private: System::Void okbutton_Click(System::Object *  sender, System::EventArgs *  e)
			 {
				 String* str = numbox->Text;
				 value = defaultv;

			 	 try
				 {
					value = System::Convert::ToSingle(str);
				 }
				 catch(...)
				 {
					value = defaultv;
				 }

				 this->Visible = false;

			 }

	};
}