#pragma once

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;

#include"appsettings.h"
#include"common.h"
#include"AutoEdit.h"
#include"BlockOutGrid.h"
#include"Global.h"

namespace bre20
{
	/// <summary> 
	/// Summary for AutotuneOptions
	///
	/// WARNING: If you change the name of this class, you will need to change the 
	///          'Resource File Name' property for the managed resource compiler tool 
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public __gc class AutotuneOptions : public System::Windows::Forms::Form
	{
	public: 
	//	static const String* dialogName = "AutotuneOptions"
		AutotuneOptions(AutoEdit* ae, Form* rom)
		{
			InitializeComponent();

			autoedit = ae;
			setupTabs(ae,rom);

			Globals::Props->NotifyDialogOpened(this,"AutotuneOptions");
		}

		bool addTabPage(TabPage* newpage){
			if(newpage == NULL)
				return false;
			this->tabControl1->TabPages->Add(newpage);
			return true;
		}
        
	protected: 
		void Dispose(Boolean disposing)
		{
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}
		AutoEdit* autoedit;
		void setupTabs(AutoEdit* ae, Form* rom);
		BlockOutGrid* grids[];

	private: System::Windows::Forms::TabControl *  tabControl1;
	private: System::Windows::Forms::TabPage *  generalOpt;
	private: System::Windows::Forms::GroupBox *  estGroup;
	private: System::Windows::Forms::GroupBox *  rtAtGroup;
	private: System::Windows::Forms::CheckBox *  estCheck;
	private: System::Windows::Forms::Label *  label1;
	private: System::Windows::Forms::TextBox *  numEstCellsBox;
	private: System::Windows::Forms::GroupBox *  genGroup;
	private: System::Windows::Forms::TextBox *  minChBox;
	private: System::Windows::Forms::TextBox *  MaxChBox;
	private: System::Windows::Forms::Label *  label2;
	private: System::Windows::Forms::Label *  label3;
	private: System::Windows::Forms::Label *  label4;
	private: System::Windows::Forms::Label *  label5;
	private: System::Windows::Forms::Label *  label6;
	private: System::Windows::Forms::Label *  label7;
	private: System::Windows::Forms::Label *  label8;
	private: System::Windows::Forms::Label *  label9;
	private: System::Windows::Forms::Label *  label10;
	private: System::Windows::Forms::TextBox *  minFreq;
	private: System::Windows::Forms::TextBox *  maxColDev;
	private: System::Windows::Forms::TextBox *  minCellWeight;
	private: System::Windows::Forms::TextBox *  maxRowDev;
	private: System::Windows::Forms::TextBox *  latencyIntervals;
	private: System::Windows::Forms::Button *  helpButton;
	private: System::Windows::Forms::Button *  okButton;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container* components;

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->tabControl1 = new System::Windows::Forms::TabControl();
			this->generalOpt = new System::Windows::Forms::TabPage();
			this->genGroup = new System::Windows::Forms::GroupBox();
			this->label5 = new System::Windows::Forms::Label();
			this->label4 = new System::Windows::Forms::Label();
			this->label3 = new System::Windows::Forms::Label();
			this->label2 = new System::Windows::Forms::Label();
			this->MaxChBox = new System::Windows::Forms::TextBox();
			this->minChBox = new System::Windows::Forms::TextBox();
			this->rtAtGroup = new System::Windows::Forms::GroupBox();
			this->helpButton = new System::Windows::Forms::Button();
			this->label10 = new System::Windows::Forms::Label();
			this->label9 = new System::Windows::Forms::Label();
			this->label8 = new System::Windows::Forms::Label();
			this->label7 = new System::Windows::Forms::Label();
			this->label6 = new System::Windows::Forms::Label();
			this->latencyIntervals = new System::Windows::Forms::TextBox();
			this->maxRowDev = new System::Windows::Forms::TextBox();
			this->minCellWeight = new System::Windows::Forms::TextBox();
			this->maxColDev = new System::Windows::Forms::TextBox();
			this->minFreq = new System::Windows::Forms::TextBox();
			this->estGroup = new System::Windows::Forms::GroupBox();
			this->label1 = new System::Windows::Forms::Label();
			this->numEstCellsBox = new System::Windows::Forms::TextBox();
			this->estCheck = new System::Windows::Forms::CheckBox();
			this->okButton = new System::Windows::Forms::Button();
			this->tabControl1->SuspendLayout();
			this->generalOpt->SuspendLayout();
			this->genGroup->SuspendLayout();
			this->rtAtGroup->SuspendLayout();
			this->estGroup->SuspendLayout();
			this->SuspendLayout();
			// 
			// tabControl1
			// 
			this->tabControl1->Anchor = (System::Windows::Forms::AnchorStyles)(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom) 
				| System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right);
			this->tabControl1->Controls->Add(this->generalOpt);
			this->tabControl1->Location = System::Drawing::Point(0, 0);
			this->tabControl1->Name = S"tabControl1";
			this->tabControl1->SelectedIndex = 0;
			this->tabControl1->Size = System::Drawing::Size(306, 360);
			this->tabControl1->TabIndex = 0;
			this->tabControl1->SelectedIndexChanged += new System::EventHandler(this, tabControl1_SelectedIndexChanged);
			// 
			// generalOpt
			// 
			this->generalOpt->Controls->Add(this->genGroup);
			this->generalOpt->Controls->Add(this->rtAtGroup);
			this->generalOpt->Controls->Add(this->estGroup);
			this->generalOpt->Location = System::Drawing::Point(4, 22);
			this->generalOpt->Name = S"generalOpt";
			this->generalOpt->Size = System::Drawing::Size(298, 334);
			this->generalOpt->TabIndex = 0;
			this->generalOpt->Text = S"General";
			// 
			// genGroup
			// 
			this->genGroup->Controls->Add(this->label5);
			this->genGroup->Controls->Add(this->label4);
			this->genGroup->Controls->Add(this->label3);
			this->genGroup->Controls->Add(this->label2);
			this->genGroup->Controls->Add(this->MaxChBox);
			this->genGroup->Controls->Add(this->minChBox);
			this->genGroup->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->genGroup->Location = System::Drawing::Point(160, 16);
			this->genGroup->Name = S"genGroup";
			this->genGroup->Size = System::Drawing::Size(128, 120);
			this->genGroup->TabIndex = 3;
			this->genGroup->TabStop = false;
			this->genGroup->Text = S"General";
			// 
			// label5
			// 
			this->label5->Location = System::Drawing::Point(104, 88);
			this->label5->Name = S"label5";
			this->label5->Size = System::Drawing::Size(8, 24);
			this->label5->TabIndex = 5;
			this->label5->Text = S"%";
			this->label5->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			// 
			// label4
			// 
			this->label4->Location = System::Drawing::Point(104, 40);
			this->label4->Name = S"label4";
			this->label4->Size = System::Drawing::Size(8, 24);
			this->label4->TabIndex = 4;
			this->label4->Text = S"%";
			this->label4->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			// 
			// label3
			// 
			this->label3->Location = System::Drawing::Point(16, 72);
			this->label3->Name = S"label3";
			this->label3->Size = System::Drawing::Size(80, 16);
			this->label3->TabIndex = 3;
			this->label3->Text = S"Max Change";
			// 
			// label2
			// 
			this->label2->Location = System::Drawing::Point(16, 24);
			this->label2->Name = S"label2";
			this->label2->Size = System::Drawing::Size(80, 16);
			this->label2->TabIndex = 2;
			this->label2->Text = S"Min Change:";
			// 
			// MaxChBox
			// 
			this->MaxChBox->Location = System::Drawing::Point(24, 88);
			this->MaxChBox->Name = S"MaxChBox";
			this->MaxChBox->Size = System::Drawing::Size(72, 20);
			this->MaxChBox->TabIndex = 1;
			this->MaxChBox->Text = S"5";
			this->MaxChBox->KeyPress += new System::Windows::Forms::KeyPressEventHandler(this, fbox_Changed);
			// 
			// minChBox
			// 
			this->minChBox->Location = System::Drawing::Point(24, 40);
			this->minChBox->Name = S"minChBox";
			this->minChBox->Size = System::Drawing::Size(72, 20);
			this->minChBox->TabIndex = 0;
			this->minChBox->Text = S"1";
			this->minChBox->KeyPress += new System::Windows::Forms::KeyPressEventHandler(this, fbox_Changed);
			// 
			// rtAtGroup
			// 
			this->rtAtGroup->Controls->Add(this->helpButton);
			this->rtAtGroup->Controls->Add(this->label10);
			this->rtAtGroup->Controls->Add(this->label9);
			this->rtAtGroup->Controls->Add(this->label8);
			this->rtAtGroup->Controls->Add(this->label7);
			this->rtAtGroup->Controls->Add(this->label6);
			this->rtAtGroup->Controls->Add(this->latencyIntervals);
			this->rtAtGroup->Controls->Add(this->maxRowDev);
			this->rtAtGroup->Controls->Add(this->minCellWeight);
			this->rtAtGroup->Controls->Add(this->maxColDev);
			this->rtAtGroup->Controls->Add(this->minFreq);
			this->rtAtGroup->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->rtAtGroup->Location = System::Drawing::Point(16, 152);
			this->rtAtGroup->Name = S"rtAtGroup";
			this->rtAtGroup->Size = System::Drawing::Size(272, 176);
			this->rtAtGroup->TabIndex = 2;
			this->rtAtGroup->TabStop = false;
			this->rtAtGroup->Text = S"Real-time Autotune";
			// 
			// helpButton
			// 
			this->helpButton->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->helpButton->Location = System::Drawing::Point(160, 136);
			this->helpButton->Name = S"helpButton";
			this->helpButton->Size = System::Drawing::Size(72, 24);
			this->helpButton->TabIndex = 17;
			this->helpButton->Text = S"Help";
			this->helpButton->Click += new System::EventHandler(this, helpButton_Click);
			// 
			// label10
			// 
			this->label10->Location = System::Drawing::Point(144, 72);
			this->label10->Name = S"label10";
			this->label10->Size = System::Drawing::Size(80, 16);
			this->label10->TabIndex = 16;
			this->label10->Text = S"Max Row Dev:";
			// 
			// label9
			// 
			this->label9->Location = System::Drawing::Point(144, 24);
			this->label9->Name = S"label9";
			this->label9->Size = System::Drawing::Size(80, 16);
			this->label9->TabIndex = 15;
			this->label9->Text = S"Max Col Dev:";
			// 
			// label8
			// 
			this->label8->Location = System::Drawing::Point(16, 120);
			this->label8->Name = S"label8";
			this->label8->Size = System::Drawing::Size(96, 16);
			this->label8->TabIndex = 14;
			this->label8->Text = S"Latency Intervals:";
			// 
			// label7
			// 
			this->label7->Location = System::Drawing::Point(24, 72);
			this->label7->Name = S"label7";
			this->label7->Size = System::Drawing::Size(88, 16);
			this->label7->TabIndex = 13;
			this->label7->Text = S"Min Cell Weight:";
			// 
			// label6
			// 
			this->label6->Location = System::Drawing::Point(24, 24);
			this->label6->Name = S"label6";
			this->label6->Size = System::Drawing::Size(80, 16);
			this->label6->TabIndex = 12;
			this->label6->Text = S"Min Freq.:";
			// 
			// latencyIntervals
			// 
			this->latencyIntervals->Location = System::Drawing::Point(40, 136);
			this->latencyIntervals->Name = S"latencyIntervals";
			this->latencyIntervals->Size = System::Drawing::Size(72, 20);
			this->latencyIntervals->TabIndex = 10;
			this->latencyIntervals->Text = S"3";
			this->latencyIntervals->KeyPress += new System::Windows::Forms::KeyPressEventHandler(this, ibox_Changed);
			// 
			// maxRowDev
			// 
			this->maxRowDev->Location = System::Drawing::Point(160, 88);
			this->maxRowDev->Name = S"maxRowDev";
			this->maxRowDev->Size = System::Drawing::Size(72, 20);
			this->maxRowDev->TabIndex = 9;
			this->maxRowDev->Text = S".05";
			this->maxRowDev->KeyPress += new System::Windows::Forms::KeyPressEventHandler(this, fbox_Changed);
			// 
			// minCellWeight
			// 
			this->minCellWeight->Location = System::Drawing::Point(40, 88);
			this->minCellWeight->Name = S"minCellWeight";
			this->minCellWeight->Size = System::Drawing::Size(72, 20);
			this->minCellWeight->TabIndex = 8;
			this->minCellWeight->Text = S".20";
			this->minCellWeight->KeyPress += new System::Windows::Forms::KeyPressEventHandler(this, fbox_Changed);
			// 
			// maxColDev
			// 
			this->maxColDev->Location = System::Drawing::Point(160, 40);
			this->maxColDev->Name = S"maxColDev";
			this->maxColDev->Size = System::Drawing::Size(72, 20);
			this->maxColDev->TabIndex = 7;
			this->maxColDev->Text = S".15";
			this->maxColDev->KeyPress += new System::Windows::Forms::KeyPressEventHandler(this, fbox_Changed);
			// 
			// minFreq
			// 
			this->minFreq->Location = System::Drawing::Point(40, 40);
			this->minFreq->Name = S"minFreq";
			this->minFreq->Size = System::Drawing::Size(72, 20);
			this->minFreq->TabIndex = 6;
			this->minFreq->Text = S"1";
			this->minFreq->KeyPress += new System::Windows::Forms::KeyPressEventHandler(this, fbox_Changed);
			// 
			// estGroup
			// 
			this->estGroup->Controls->Add(this->label1);
			this->estGroup->Controls->Add(this->numEstCellsBox);
			this->estGroup->Controls->Add(this->estCheck);
			this->estGroup->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->estGroup->Location = System::Drawing::Point(16, 16);
			this->estGroup->Name = S"estGroup";
			this->estGroup->Size = System::Drawing::Size(128, 120);
			this->estGroup->TabIndex = 1;
			this->estGroup->TabStop = false;
			this->estGroup->Text = S"Estimation";
			// 
			// label1
			// 
			this->label1->Location = System::Drawing::Point(16, 64);
			this->label1->Name = S"label1";
			this->label1->Size = System::Drawing::Size(96, 16);
			this->label1->TabIndex = 2;
			this->label1->Text = S"Max Est Cell Gap: ";
			// 
			// numEstCellsBox
			// 
			this->numEstCellsBox->Location = System::Drawing::Point(24, 80);
			this->numEstCellsBox->Name = S"numEstCellsBox";
			this->numEstCellsBox->Size = System::Drawing::Size(88, 20);
			this->numEstCellsBox->TabIndex = 1;
			this->numEstCellsBox->Text = S"4";
			this->numEstCellsBox->KeyPress += new System::Windows::Forms::KeyPressEventHandler(this, ibox_Changed);
			// 
			// estCheck
			// 
			this->estCheck->Checked = true;
			this->estCheck->CheckState = System::Windows::Forms::CheckState::Checked;
			this->estCheck->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->estCheck->Location = System::Drawing::Point(16, 32);
			this->estCheck->Name = S"estCheck";
			this->estCheck->Size = System::Drawing::Size(96, 16);
			this->estCheck->TabIndex = 0;
			this->estCheck->Text = S"Estimate gaps";
			// 
			// okButton
			// 
			this->okButton->Anchor = (System::Windows::Forms::AnchorStyles)(System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Right);
			this->okButton->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->okButton->Location = System::Drawing::Point(192, 368);
			this->okButton->Name = S"okButton";
			this->okButton->Size = System::Drawing::Size(104, 32);
			this->okButton->TabIndex = 4;
			this->okButton->Text = S"OK";
			this->okButton->Click += new System::EventHandler(this, okButton_Click);
			// 
			// AutotuneOptions
			// 
			this->AcceptButton = this->okButton;
			this->AutoScaleBaseSize = System::Drawing::Size(5, 13);
			this->ClientSize = System::Drawing::Size(306, 407);
			this->ControlBox = false;
			this->Controls->Add(this->tabControl1);
			this->Controls->Add(this->okButton);
			this->MaximizeBox = false;
			this->Name = S"AutotuneOptions";
			this->ShowInTaskbar = false;
			this->Text = S"Autotune Options";
			this->Load += new System::EventHandler(this, AutotuneOptions_Load);
			this->tabControl1->ResumeLayout(false);
			this->generalOpt->ResumeLayout(false);
			this->genGroup->ResumeLayout(false);
			this->rtAtGroup->ResumeLayout(false);
			this->estGroup->ResumeLayout(false);
			this->ResumeLayout(false);

		}		
	private: System::Void helpButton_Click(System::Object *  sender, System::EventArgs *  e)
			 {
				 MessageBox::Show("For information on the realtime autotune options, read the bre.exe.config file.","BRE");
			 }

private: System::Void okButton_Click(System::Object *  sender, System::EventArgs *  e)
		 {
			 try
			 {
				Globals::Props->setParam(this,S"atLatencyIntervals",latencyIntervals->Text);
				Globals::Props->setParam(this,S"atMinCellWeight",minCellWeight->Text);
				Globals::Props->setParam(this,S"atRtFrequency",minFreq->Text);
				Globals::Props->setParam(this,S"atMaxColDeviation",maxColDev->Text);
				Globals::Props->setParam(this,S"atMaxRowDeviation",maxRowDev->Text);
				Globals::Props->setParam(this,S"atMinDifference",minChBox->Text);
				Globals::Props->setParam(this,S"atMaxDifference",MaxChBox->Text);
				Globals::Props->setParam(this,S"atNumEstimatedCells",numEstCellsBox->Text);

				if(this->estCheck->Checked)
					Globals::Props->setParam(this,S"atEstimateBlankCells","1");
				else
					Globals::Props->setParam(this,S"atEstimateBlankCells","0");

				for(int i = 0; i<grids->Length; i++)
					grids[i]->setBlockout(autoedit);

				this->Close();
			 }
			 catch(...)
			 {
			 }
		 }

private: System::Void AutotuneOptions_Load(System::Object *  sender, System::EventArgs *  e)
		 {
			 try
			 {
				this->latencyIntervals->Text = Globals::Props->getIntParam(S"atLatencyIntervals").ToString();
				this->minCellWeight->Text = Globals::Props->getFloatParam(S"atMinCellWeight").ToString("0.##");
				this->minFreq->Text = Globals::Props->getFloatParam(S"atRtFrequency").ToString("0.##");
				this->maxColDev->Text = Globals::Props->getFloatParam(S"atMaxColDeviation").ToString("0.##");
				this->maxRowDev->Text = Globals::Props->getFloatParam(S"atMaxRowDeviation").ToString("0.##");
				this->minChBox->Text = Globals::Props->getFloatParam(S"atMinDifference").ToString("0.##");
				this->MaxChBox->Text = Globals::Props->getFloatParam(S"atMaxDifference").ToString("0.##");

				this->numEstCellsBox->Text = Globals::Props->getIntParam(S"atNumEstimatedCells").ToString();

				this->estCheck->Checked = Globals::Props->getBoolParam(S"atEstimateBlankCells");

		//		if(tmp == 1)
		//			this->estCheck->Checked = true;
		//		else
		//			this->estCheck->Checked = false;
			 }
			 catch(...)
			 {
			 }

		 }

 private: System::Void tabControl1_SelectedIndexChanged(System::Object *  sender, System::EventArgs *  e)
		 {
		 }

private: System::Void fbox_Changed(System::Object *  sender, System::Windows::Forms::KeyPressEventArgs *  e)
		 {
			 Common::handleDoubleKeyPress(static_cast<TextBox*>(sender),e,false);
		 }

private: System::Void ibox_Changed(System::Object *  sender, System::Windows::Forms::KeyPressEventArgs *  e)
		 {
			 Common::handleIntKeyPress(static_cast<TextBox*>(sender),e,false);
		 }

};
}