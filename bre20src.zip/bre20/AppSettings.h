#pragma once

using namespace System;
using namespace System::Text;
using namespace System::Xml;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;

namespace bre20
{
	public __gc class AppSettings
	{
	protected:
		String * _configFileName; //local var to hold the config file name
//		Config * configFileType; //local var to hold the config file type (private or shared)

		void InitializeConfigFile();

	public:
		AppSettings();//(AppSettings::Config * configFileType);
		String* GetSetting(String* key);
		void SaveSetting(String* key, String* value);
		void DeleteSetting(String* key);

	//	enum Config
	//	{
	//		SharedFile,  //all users use the same config file
	//		PrivateFile, //each user has their own config file
	//		SystemFile,   //all users use the same config file, config file put at System folder
	//		LocalFile
	//	};

		String* getConfigFileName()
		{
			return _configFileName;
		}

	};
}
