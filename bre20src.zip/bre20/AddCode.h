#pragma once
#include "common.h"

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;


namespace bre20
{
	/// <summary> 
	/// Summary for AddCode
	///
	/// WARNING: If you change the name of this class, you will need to change the 
	///          'Resource File Name' property for the managed resource compiler tool 
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public __gc class AddCode : public System::Windows::Forms::Form
	{
	public: 
		AddCode(void)
		{
			code = -2;
			InitializeComponent();
		}

		int getCode()
		{
			return code;
		}
        
	protected: 
		void Dispose(Boolean disposing)
		{
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}
	private: System::Windows::Forms::Label *  label1;
	private: System::Windows::Forms::TextBox *  textBox1;
	private: System::Windows::Forms::Button *  cancel;
	private: System::Windows::Forms::Button *  okbutton;

	private:
		int code;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container* components;

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = new System::Windows::Forms::Label();
			this->textBox1 = new System::Windows::Forms::TextBox();
			this->cancel = new System::Windows::Forms::Button();
			this->okbutton = new System::Windows::Forms::Button();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->Location = System::Drawing::Point(16, 24);
			this->label1->Name = S"label1";
			this->label1->Size = System::Drawing::Size(264, 40);
			this->label1->TabIndex = 0;
			this->label1->Text = S"Type in the number of the CEL code you want to disable. It will be added to the l" 
				S"ist of disabled CEL codes.";
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(16, 80);
			this->textBox1->Name = S"textBox1";
			this->textBox1->Size = System::Drawing::Size(264, 20);
			this->textBox1->TabIndex = 1;
			this->textBox1->Text = S"";
			this->textBox1->KeyPress += new System::Windows::Forms::KeyPressEventHandler(this, textBox1_KeyPress);
			// 
			// cancel
			// 
			this->cancel->DialogResult = System::Windows::Forms::DialogResult::Cancel;
			this->cancel->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->cancel->Location = System::Drawing::Point(80, 128);
			this->cancel->Name = S"cancel";
			this->cancel->Size = System::Drawing::Size(96, 32);
			this->cancel->TabIndex = 2;
			this->cancel->Text = S"Cancel";
			this->cancel->Click += new System::EventHandler(this, cancel_Click);
			// 
			// okbutton
			// 
			this->okbutton->DialogResult = System::Windows::Forms::DialogResult::OK;
			this->okbutton->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->okbutton->Location = System::Drawing::Point(184, 128);
			this->okbutton->Name = S"okbutton";
			this->okbutton->Size = System::Drawing::Size(96, 32);
			this->okbutton->TabIndex = 3;
			this->okbutton->Text = S"OK";
			this->okbutton->Click += new System::EventHandler(this, okbutton_Click);
			// 
			// AddCode
			// 
			this->AcceptButton = this->okbutton;
			this->AutoScaleBaseSize = System::Drawing::Size(5, 13);
			this->CancelButton = this->cancel;
			this->ClientSize = System::Drawing::Size(296, 174);
			this->ControlBox = false;
			this->Controls->Add(this->okbutton);
			this->Controls->Add(this->cancel);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->label1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedDialog;
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = S"AddCode";
			this->Text = S"Add CEL Code Disable";
			this->Closing += new System::ComponentModel::CancelEventHandler(this, AddCode_Closing);
			this->ResumeLayout(false);

		}		
			
		void okbutton_Click(System::Object *  sender, System::EventArgs *  e)
		{
			try
			{
				code = Convert::ToInt32(textBox1->Text);
				DialogResult = DialogResult::OK;
			}
			catch(...)
			{
				DialogResult = DialogResult::Cancel;
			}
			Close();
		}
		void cancel_Click(System::Object *  sender, System::EventArgs *  e)
		{
			DialogResult = DialogResult::Cancel;
			Close();
		}

		void AddCode_Closing(System::Object *  sender, System::ComponentModel::CancelEventArgs *  e)
		{
		//	cancel_Click(NULL,NULL);
		}

		void textBox1_KeyPress(System::Object *  sender, System::Windows::Forms::KeyPressEventArgs *  e)
		{
			Common::handleIntKeyPress(static_cast<TextBox*>(sender),e,false);
		}
};
}