#include "StdAfx.h"
#include "afrmap.h"

RomRep::AfrMap::AfrMap(int x, int y, unsigned int loc, unsigned char themap __gc[,],
					   unsigned char fil __gc[],int ind, int mod):Map(x,y,loc,fil,ind,mod)
{
	Map::populate(themap);
}

RomRep::AfrMap::~AfrMap(void)
{
}


float RomRep::AfrMap::calculate(int x, int y, int intval)
{
	return ((float)intval/25.0F)+10.0F;
}

int RomRep::AfrMap::calculate(int x, int y, float mapval)
{
	return (int)((mapval - 10.0F)*25.0F);
}