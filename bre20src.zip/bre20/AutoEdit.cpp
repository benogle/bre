#include "StdAfx.h"
#include "AutoEdit.h"
#include "common.h"
#include "child.h"

bre20::AutoEdit::AutoEdit(Form* ecu)
{
	romWind = ecu;
	rom = static_cast<child*>(ecu)->getRom();
	rom->add_OnTargetAfrChanged(new RomRep::TargetAfrChangeHandler(this,afr_AfrChanged));

	weights = new float __gc[2,2];

	blockout = new bool __gc[rom->getNumMaps(),rom->getWidth(),rom->getHeight()];

	lgchange = 1.0;
	smchange = 1.0;

	percentchange = true;

	atmin = 1.0;
	atmax = 1.0;
	autotune = false;
}

bre20::LoggerKey* bre20::AutoEdit::getLoggerKey()
{
	if(rtatkey == NULL)
		rtatkey = new LoggerKey("Tuner Adj.",true,false);
	return rtatkey;
}

void bre20::AutoEdit::changeFuel( float change)
{
	//change is in the format percentChange/100 for percentage.
	if(blockout != NULL && weights != NULL)
	{
		if(curcol >= 0 && curfrow >= 0)
		{
			for(int i = 0; i<=weights->GetUpperBound(0); i++)
			{
				for(int j = 0; j<=weights->GetUpperBound(1); j++)
				{
					//current cell
					if(weights[i,j] > 0.025)
					{
						float num = static_cast<child*>(romWind)->getFuelCell(curcol+i,curfrow+j,index);

						if(percentchange)
							num = num*(change*weights[i,j]+1);
						else
							num = num+change*weights[i,j];

						static_cast<child*>(romWind)->setFuelCell(curcol+i,curfrow+j,num,index);
					}//end inner if
				}//end inner for
			}//end outer for
		}//end outer if
		romWind->Refresh();
	}
}
//end change fuel

void bre20::AutoEdit::setCellWeight(int col, int row, float value)
{
	if(col >= 0 && row >=0 && col<=weights->GetUpperBound(0) && row<=weights->GetUpperBound(1) &&
		value >= 0.0 && value <= 1.0)
		weights[col,row] = value;

}
void bre20::AutoEdit::setBlockOut(int index, int col, int row, bool value)
{
	if(col >= 0 && row >=0 && col<rom->getWidth() && row <rom->getHeight() &&
		index <= blockout->GetUpperBound(0))
		blockout[index,col,row] = value;

}

void bre20::AutoEdit::DlEditInit()
{
	try
	{
		String* str = Globals::Props->getParam(S"emuSmallChange");

		if(str->Trim()->Chars[str->Length-1] == '%')
			percentchange = true;

		if(percentchange)
			str = str->Substring(0,str->Length-1);

		this->smchange = Convert::ToSingle(str)/100.0F;

		str = Globals::Props->getParam(S"emuLargeChange");

		if(percentchange)
			str = str->Substring(0,str->Length-1);

		this->lgchange = Convert::ToSingle(str)/100.0F;
	}
	catch(...){}
}

void bre20::AutoEdit::RtAutoTuneInit()
{
	int width = rom->getWidth();
	int height = rom->getHeight();
	int nummaps = rom->getNumMaps();

	afrmap = new float __gc[nummaps,width,height];

	for(int i = 0; i<nummaps; i++)
	{
		float tafrmap __gc[,] = rom->getLambdaMap(index);
		for(int x = 0; x<width; x++)
			for(int y = 0; y<height; y++)
				afrmap[i,x,y] = tafrmap[x,y];
	}

	goodsamples = new int __gc[nummaps,width,height];//[rom->getRom()->getWidth(),rom->getRom()->getHeight()];

	if(afrmap != NULL)
	{
		try
		{
			intervalcount = 0;
			numintervals = Globals::Props->getIntParam(S"atLatencyIntervals");
			
			atavg = new float __gc[nummaps,width,height];
			atfreq = new float __gc[nummaps,width,height];

			atminfreq = Globals::Props->getFloatParam(S"atRtFrequency");
			
			atmin = Globals::Props->getFloatParam(S"atMinDifference")/100.0F;
			atmax = Globals::Props->getFloatParam(S"atMaxDifference")/100.0F;
			atmincell = Globals::Props->getFloatParam(S"atMinCellWeight");

			atmaxcoldev = Globals::Props->getFloatParam(S"atMaxColDeviation");
			atmaxrowdev = Globals::Props->getFloatParam(S"atMaxRowDeviation");

			autotune = true;
		}
		catch(...)
		{}					
	}//end if
}
void bre20::AutoEdit::RtAutoTuneRun()
{
		//r-t auto tune...
	if(autotune && afrmap != NULL)
	{
		intervalcount++;

		int width = rom->getWidth();
		int height = rom->getHeight();

		rtatkey->Value = "";
		
		bool refresh = false;
		if(curcol >= 0 && curfrow >= 0 && curfrow+1<height && curcol+1<width)
			for(int i = 0; i<=weights->GetUpperBound(0); i++)
				for(int j = 0; j<=weights->GetUpperBound(1); j++)
					if(weights[i,j] > 0.025)
						if(setFuelCell(curcol,curfrow,weights[i,j],afr,afrmap[index,curcol,curfrow]))
							refresh = true;
	}
}
void bre20::AutoEdit::RtAutoTuneStop()
{
	autotune = false;

	atavg = NULL;
	atfreq = NULL;
	goodsamples = NULL;
}

//perc is the weight (percent; 0-1) of this cells fuel value on the measured afr 
bool bre20::AutoEdit::setFuelCell(int col, int row, float perc, float afrmeasure, float afrtarget)
{
	//if enough intervals have not passed, do nothing
	if(intervalcount-goodsamples[index,col,row]<=numintervals)
		return false;
	else
		goodsamples[index,col,row] = intervalcount;

	//if this sample is less than the minimum cell weight, then do nothing.
	if(perc < atmincell)
		return false;

	atavg[index,col,row] = (atavg[index,col,row] * atfreq[index,col,row]) + afrmeasure*perc;
	atfreq[index,col,row]+= perc;
	atavg[index,col,row] = atavg[index,col,row]/atfreq[index,col,row];

	if(atfreq[index,col,row]<atminfreq)
		return false;

	float div = atavg[index,col,row]/afrtarget-1.0F;

	// post interp checking
	if(atfreq[index,col,row] >= 1.0F)
		perc = div;
	else
		perc = atfreq[index,col,row]*div;

	if(Math::Abs(perc) < atmin)
		return false;

	if(Math::Abs(perc) > atmax)
	{
		if(div<0.0)
			perc = -atmax;
		else
			perc = atmax;
	}

	//end post interp checking

	/* 
	//pre interp checking

	if(Math::Abs(div) < atmin)
		return;

	if(Math::Abs(div) > atmax)
	{
		if(div<0.0)
			div = -atmax;
		else
			div = atmax;
	}

	perc *= div;

	//end pre interp checking
	*/

	perc+= 1.0;

	//pretty much if we hit the mark more than 5 times we are done with that cell.
//	if(goodsamples[col,row] > 5)
//	{
//		rom->Refresh();
//		return false;
//	}

	//make the adjustment...
	float curcell = static_cast<child*>(romWind)->getFuelCell(col,row,index);
	float newcurcell = curcell*perc;

	if(newcurcell <0)
		return false;

	bool ok = true;

	//now make sure the new fuel value is within the col and row deviations.
	float surcells __gc[] = new float __gc[4];
	surcells[0] = static_cast<child*>(romWind)->getFuelCell(col+1,row,index);//east
	surcells[1] = static_cast<child*>(romWind)->getFuelCell(col-1,row,index);//west
	surcells[2] = static_cast<child*>(romWind)->getFuelCell(col,row+1,index);//north
	surcells[3] = static_cast<child*>(romWind)->getFuelCell(col,row-1,index);//south

	for(int i = 0; i<surcells->Length; i++)
	{
		float max = atmaxcoldev;
		if(i>=2)
			max = atmaxrowdev;
		if(surcells[i] > 1.0)
		{
			float nperc = (surcells[i]/newcurcell)-1.0F;
			if(Math::Abs(nperc)>max)
				ok = false;
		}
	}

	if(ok)
	{
		//apply the correction
		static_cast<child*>(romWind)->setFuelCell(col,row,newcurcell,index);

		//reset that cell
		atfreq[index,col,row] = 0.0F;
		atavg[index,col,row] = 0.0F;

		//add to the logger key.
		if(rtatkey != NULL)
			rtatkey->Value = String::Concat(rtatkey->Value,S"(",col.ToString(),S"`",row.ToString(),
			S") ",perc.ToString("0.0000"),S"; ");
	}

	return true;
}

float bre20::AutoEdit::parseWeights(String* weights) __gc[,]
{
	__wchar_t w __gc[] = {'|'};
	String* strs[] = weights->Split(w);
	float fweight __gc[,] = new float __gc[2,2];
	for(int i = 0; i< strs->Length; i++)
	{
		try
		{
			fweight[i%2,i/2] = Convert::ToSingle(strs[i]);
		}
		catch(FormatException* ex)
		{
			fweight[i%2,i/2] = 0.0f;
		}
	}
	return fweight;
}

void bre20::AutoEdit::afr_AfrChanged(Object* sender, RomRep::AfrChangeArgs* e)
{

}