#pragma once

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;

//comment this out if its a release
#define BETA

#define VERSION "2.2.4b2"

namespace bre20
{
	/// <summary> 
	/// Summary for About
	///
	/// WARNING: If you change the name of this class, you will need to change the 
	///          'Resource File Name' property for the managed resource compiler tool 
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public __gc class About : public System::Windows::Forms::Form
	{
	public: 
		About(void)
		{
			InitializeComponent();
			this->Text = String::Concat(S"About ",BRETITLE);

			label1->Text = String::Concat(label1->Text,BETA_TEXT);
		}

	#ifdef BETA
		static String* BRETITLE = String::Concat(S"BRE ",VERSION," beta");
	#else
		static String* BRETITLE = String::Concat(S"BRE ",VERSION);
	#endif

	private:
	#ifdef BETA
		static String* BETA_TEXT = S"\n\nPlease note that this IS a beta release. If you find "
							S"anything you feel is a bug, post it on the BRE forum at pgmfi or e-mail me.";
	#else
		static String* BETA_TEXT = S"";
	#endif
        
	protected: 
		void Dispose(Boolean disposing)
		{
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}
	private: System::Windows::Forms::Label *  label1;
	private: System::Windows::Forms::Button *  button1;
	private: System::Windows::Forms::Label *  label2;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container* components;

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = new System::Windows::Forms::Label();
			this->button1 = new System::Windows::Forms::Button();
			this->label2 = new System::Windows::Forms::Label();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->Location = System::Drawing::Point(40, 16);
			this->label1->Name = S"label1";
			this->label1->Size = System::Drawing::Size(488, 136);
			this->label1->TabIndex = 0;
			this->label1->Text = S"BRE is copyright Ben Ogle 2004, 2005, and 2006\n\nBRE stands for \"Ben\'s Rom Editor\"" 
				S"\n\nBy using BRE or anything else created by me you agree to assume all responsibi" 
				S"lity for anything and everything that may happen to you, your car, or anything e" 
				S"lse in your entire life.";
			// 
			// button1
			// 
			this->button1->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->button1->Location = System::Drawing::Point(392, 440);
			this->button1->Name = S"button1";
			this->button1->Size = System::Drawing::Size(120, 32);
			this->button1->TabIndex = 1;
			this->button1->Text = S"OK";
			this->button1->Click += new System::EventHandler(this, button1_Click);
			// 
			// label2
			// 
			this->label2->Location = System::Drawing::Point(16, 152);
			this->label2->Name = S"label2";
			this->label2->Size = System::Drawing::Size(512, 256);
			this->label2->TabIndex = 2;
			this->label2->Text = S"If you are interested in the newest features, read the readme in the BRE zip file" 
				S". Additionally, documentation, including the scripting API and the change log is" 
				S" on the web at: \nwww.ef-honda.com/ben/bre.\n\nThe Grid control is a modified versi" 
				S"on of the SimpleGrid control which is freely available.\nThe graph control is cop" 
				S"yright 2005 Brian Rogers from pgmfi (Thank you very much).\nAll OBD0 VTEC datalog" 
				S"ging code is an implementation of the code dip/Anton posted on pgmfi.org.\n\nIf yo" 
				S"u use and like BRE please feel free to contribute money (via paypal at ogle6@hot" 
				S"mail.com) or car parts to compensate for my time and effort in writing this appl" 
				S"ication and the ECU code that goes with it. \n\nIf you are interested in contribut" 
				S"ing time and effort and have some coding skills e-mail me at ogle6@hotmail.com. " 
				S"I can find plenty for you to do. If you want to test code, e-mail me. If you wan" 
				S"t to help me write an FAQ type document, e-mail me. If you have any questions ab" 
				S"out BRE post in the BRE forum on pgmfi. \n\nI want to hear from you. If you use or" 
				S" have used BRE please e-mail me and tell me how it went. I want to hear it all: " 
				S"good, bad, and ugly. I especially want to hear from you if you used the boost co" 
				S"de. The more feedback I get, the better BRE and the associated ECU code will be." 
				S" \n\nThank you Nigel Curtis, Dave (nominous), Ben deAngeli, and Zainal Hasnan for " 
				S"your contributions.";
			// 
			// About
			// 
			this->AcceptButton = this->button1;
			this->AutoScaleBaseSize = System::Drawing::Size(5, 13);
			this->ClientSize = System::Drawing::Size(530, 487);
			this->ControlBox = false;
			this->Controls->Add(this->button1);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedDialog;
			this->MinimizeBox = false;
			this->Name = S"About";
			this->ShowInTaskbar = false;
			this->TopMost = true;
			this->ResumeLayout(false);

		}		
	private: System::Void button1_Click(System::Object *  sender, System::EventArgs *  e)
			 {
				 this->Visible = false;
			 }

	};
}