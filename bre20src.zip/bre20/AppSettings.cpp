#include "StdAfx.h"
#include "appsettings.h"

bre20::AppSettings::AppSettings()//(AppSettings::Config * configFileType)
{
//	_configFileType = configFileType; //remember this setting

    InitializeConfigFile(); //setup the filename and location
}

//a class for reading and writing XML style application settings
//sample usage:
//  Create the object -
//      Dim a As New AppSettings(AppSettings.Config.PrivateFile)
//  Retrieve a setting -
//      Dim myString As String = a.GetSetting("SettingName")
//  Save a setting -
//      a.SaveSetting("SettingName", value)
//  Delete a setting -
//      a.DeleteSetting("SettingName")

//initialize the apps config file, create it if it doesn//t exist
void bre20::AppSettings::InitializeConfigFile()
{
	StringBuilder* sb = new StringBuilder();
    //build the path\filename depending on the location of the config file
 //   switch(_configFileType)
	//{
	//	case Config::PrivateFile: //each user has their own personal settings
 //           //use "\documents and settings\username\application data" for the config file directory
	//		sb->Append(Environment.GetFolderPath(Environment::SpecialFolder::ApplicationData));
	//		break;
	//	case Config::SharedFile: //all users share the same settings
 //           //use "\documents and settings\All Users\application data" for the config file directory
	//		sb->Append(Environment.GetFolderPath(Environment::SpecialFolder::CommonApplicationData));
	//		break;
	//	case Config::SystemFile:
 //           //use "\Winnt\System32" for the config file directory
	//		sb->Append(Environment.GetFolderPath(Environment::SpecialFolder::System));
	//		break;
	//	case Config::LocalFile:
 //           //use "\Winnt\System32" for the config file directory
	//		sb->Append(Application::ExecutablePath);
	//	
	//}

    //add the product name

	sb->Append(Application::ExecutablePath);

	//if(_configFileType != Config::LocalFile)
	//{
	//	sb->Append(S"\\");
	//	sb->Append(Application::ProductName);

	//	    //finish building the file name
	//	sb->Append("\\");
	//	sb->Append(Application::ProductName);
	//}

	sb->Append(".config");

    _configFileName = sb->ToString(); //completed config filename
}

//get an application setting by key value
String* bre20::AppSettings::GetSetting(String* key)
{
    //xml document object
    XmlDocument* xd = new XmlDocument();

    //load the xml file
    xd->Load(_configFileName);

	String* path = String::Concat(S"/configuration/appSettings/add[@key=\"",key, S"\"]");
    //query for a value
	XmlNode* node = xd->DocumentElement->SelectSingleNode(path);

    //return the value or nothing if it doesn//t exist
    if(node != NULL)
        return node->Attributes->GetNamedItem(S"value")->Value;
	else
        return NULL;
}

//save an application setting, takes a key and a value
void bre20::AppSettings::SaveSetting(String* key, String* value)
{
    //xml document object
    XmlDocument* xd = new XmlDocument();

    //load the xml file
    xd->Load(_configFileName);

    //query for a value
	XmlElement* node = static_cast<XmlElement*>(xd->DocumentElement->SelectSingleNode(String::Concat("/configuration/appSettings/add[@key=\"",key, "\"]")));

    if(node != NULL)
        //key found, set the value
        node->Attributes->GetNamedItem("value")->Value = value;
	else
	{
        //key not found, create it
        node = xd->CreateElement("add");
        node->SetAttribute("key", key);
        node->SetAttribute("value", value);

        //look for the appsettings node
        XmlNode * root = xd->DocumentElement->SelectSingleNode(S"/configuration/appSettings");

        //add the new child node (this key)
        if(root!= NULL)
            root->AppendChild(node);
		else
		{
            try
			{
                //appsettings node didn//t exist, add it before adding the new child
                root = xd->DocumentElement->SelectSingleNode("/configuration");
                root->AppendChild(xd->CreateElement("appSettings"));
                root = xd->DocumentElement->SelectSingleNode("/configuration/appSettings");
                root->AppendChild(node);
			}
            catch(Exception * ex)
			{
                //failed adding node, throw an error
                throw new Exception("Could not set value", ex);
			}
		}
	}

    //finally, save the new version of the config file
    xd->Save(_configFileName);
}

//delete an application setting, takes a key and a value
void bre20::AppSettings::DeleteSetting(String* key)
{
    //xml document object
    XmlDocument* xd = new XmlDocument();

    //load the xml file
    xd->Load(_configFileName);

    //query for a value
	XmlElement* node = static_cast<XmlElement*>(xd->DocumentElement->SelectSingleNode(String::Concat("/configuration/appSettings/add[@key=\"",key, "\"]")));

    if(node != NULL)
	{
        //key found, delete the value

        //look for the appsettings node
        XmlNode * root = xd->DocumentElement->SelectSingleNode("/configuration/appSettings");
        if(root!= NULL)
            root->RemoveChild(node);
	}

    //finally, save the new version of the config file
    xd->Save(_configFileName);
}
