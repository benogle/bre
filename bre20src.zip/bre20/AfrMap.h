//#pragma unmanaged

//#if !defined BENS_OBD0AFRMAP_H
//#define BENS_OBD0AFRMAP_H

#pragma once

using namespace System;

#include "map.h"
//#include <Cmath>

namespace RomRep
{
	[Serializable] public __gc class AfrMap : public Map
	{
	public:
	
	//	AfrMap(void);
		virtual ~AfrMap(void);

		
		AfrMap(int x, int y, unsigned int loc, unsigned char themap __gc[,],unsigned char fil __gc[], int ind, int mod);

	//	virtual void setVal(int x, int y, int val);

		virtual float calculate(int x, int y, int intval);
		virtual int calculate(int x, int y, float mapval);	

		virtual RomRep::ByteChange* setMultiplier(int column, int val){return NULL;}
		virtual int getMultiplierLocation(int column){return 0;}
	};
}

////#endif